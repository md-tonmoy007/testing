age = 13
print(age)