myName = "raisa"

def testfunc():
    age = 13
    print(f"I am {myName}")
    if(True):
        print(myName)


print(age)

testfunc()