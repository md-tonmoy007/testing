


myName = "raisa"

def testfunc(Name = "jifat"):
    print(f"hello {Name}")




testfunc()
testfunc()
testfunc("Tonmoy")
testfunc(myName)
testfunc("saroar")