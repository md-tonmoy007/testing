a = 5 # default
b = int(input("b: "))

a = b

print(a)