age = 18

if age >= 18:
    print("eligible")
    print("you can vote whoever you want")
    print("u should vote")

print("this output will be shown no matter what")
