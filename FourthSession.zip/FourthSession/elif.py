age = 18

if age == 18:
    print("Equal to 18")
elif age > 18:
    print("greater than 18")
else:
    print("less than 18")