fav = {
    "jifat" : 21,
    "Raisa" : 11,
}



print(fav["Raisa"])