age = 19 

if age > 18:
    print("greater than 18")
else:
    print("less than 18")