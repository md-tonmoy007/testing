name = "Raisa"

if(name == "raisa"):
    print(True)
else:
    print(False)