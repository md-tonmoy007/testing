myAge = 18
myName = "John"

print(id(myAge))
print(id(myName))

myAge = 19
print(id(myAge))
