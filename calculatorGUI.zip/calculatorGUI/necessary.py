# name = ""
# num = 1

#  +=

# name = "raisa"
# name += "R"  #name = name + "R"
# print(name)

# newName = name + str(num)

# for i in range(0, 3):
#     newName = name+str(num)

# print(newName)


number = ""

add = 1

for i in range(3):
    number += str(add)


print(number)