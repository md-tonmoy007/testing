myint = 1
myFloat = 5.88888
myStr = "John Doe"
myCharacterStr = "J"
myBoolean = True
myOtherBoolean = False
