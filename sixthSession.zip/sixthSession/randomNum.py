import random


print(random.randint())

