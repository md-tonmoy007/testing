# print 1-100 numbers


for i in range(1, 101):

    if(i % 2 == 0):
        pass
    else:
        print(i)
        



# print(   5 != 6   )
# print(range(1, 10)) # output - [1, 2, 3, 4, 5, 6, 7, 8, 9]