# name = ["jifat", "raisa", "saroar", "tonmoy"]
name = "Raisa"

for i in name:
    print(i)