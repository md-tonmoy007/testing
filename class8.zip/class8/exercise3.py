# ingredients = ['snails', 'leeches', 'gorilla belly-button lint','caterpillar eyebrows', 'centipede toes']
# print all the characters from the list


# ------- Hint -------------------
# first use a loop to print all the element from the loop
# then use another nested loop to print the character from the elements