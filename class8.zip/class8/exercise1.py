# print all the even number from 1 - 1000
