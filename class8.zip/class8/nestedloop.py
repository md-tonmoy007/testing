name = ["Jifat", "Raisa"]

for i in name:
    print("starting a loop")

    for j in i:
        print(j)