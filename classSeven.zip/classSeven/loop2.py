favFruits = ["apple", "banana", "mango", "strawberry", "pineapple"]


print(len(favFruits))
# for i in range(0, 5):
#     print(favFruits[i])


# print("apple" in favFruits)

# print(favFruits[0])
# print(favFruits[1])
# print(favFruits[2])
# print(favFruits[3])
# print(favFruits[4])