
print("Before loop")

for i in range(0,5):
    print("while looping")
    print(i)

