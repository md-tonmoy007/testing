# string and list are not same 
# string and list has same functionalities


# name = input("name: ")
name = input("name : ")
size = len(name)

for i in range(0, size):
    print(name[i])

#print(name[3]) # what is the output?
# for i in range(0, 5):
#     print(name[i])