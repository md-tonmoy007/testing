# example 1 

count = 0

while(True):
    print(count)
    if(count >= 5):
        break
    
    count = count+1
