for i in range(0, 10):
    if (i == 5):
        continue

    print(i)