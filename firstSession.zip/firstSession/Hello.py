print("Hello world")






















# Comment
# use "#" sign for commenting a line
# use """ this for multiple line commenting













""" 
A Keyboard shortcut for maximum Text editor for commenting is
            "CTRL+/"
""" 

