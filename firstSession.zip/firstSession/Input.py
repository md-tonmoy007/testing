Name = input("What is your name?")

print(Name)

