myVar = "Name"
myAge = 12
myFavNum = 12.5



print(myVar)
print(myAge)
print(myFavNum)




# Create a variable named "MyName" and assign the value "_name" to it.











# Jony = Rony = Tony = 300
# Jony, Rony, Tony = 100, 200, 300




# type of variable
# int, string, float
# print(type(myAge))




"""
Rules for Python variables:

- A variable name must start with a letter or the underscore character
- A variable name cannot start with a number
- A variable name can only contain alpha-numeric characters and underscores (A-z, 0-9, and _ )
- Variable names are case-sensitive (age, Age and AGE are three different variables)

"""



# myvar = "John"
# my_var = "John"
# 2myvar = "John"
# _my_var = "John"
# myVar = "John"
# my-var = "John"
# MYVAR = "John"
# my var = "John"
# myvar2 = "John"





# id
