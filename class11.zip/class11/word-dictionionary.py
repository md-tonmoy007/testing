dictionary = {
    "cat": "a small domesticated carnivore, Felis domestica or F. catus, bred in a number of varieties.",
    "man": "Ekjon purush",
    "women": "nari",
    "light": "bati",
}



userInput = input("Write a word for meaning: ")
print(f"Meaning of the word {userInput} is :")
print(dictionary[userInput])
