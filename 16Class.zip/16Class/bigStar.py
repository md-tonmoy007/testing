import turtle

t = turtle.Pen()

t.forward(50)
# turtle.forward(50)


t.mainloop()