# https://realpython.com/beginners-guide-python-turtle/

import turtle

for i in range(0, 8):
    turtle.forward(50)
    turtle.left(225)



turtle.mainloop()