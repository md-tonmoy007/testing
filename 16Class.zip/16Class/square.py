import turtle

for i in range(0, 6):
    turtle.forward(50)
    turtle.left(60)



    # 90 - 4 ta
    # 60 - 6 ta
    # 45 - 8 ta

turtle.mainloop()